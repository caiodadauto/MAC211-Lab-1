void empilha(double x);
double desempilha();
void Limpa_Pilha();
void Lista_Pilha();
