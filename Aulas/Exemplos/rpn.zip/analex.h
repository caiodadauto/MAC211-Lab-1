typedef enum {
  NUMERO,
  SOMA,  
  SUB,   
  MUL,   
  DIV,   
  LIMPA, 
  PRINT, 
  NEG,
  INV,
  LISTA,
  FIM
} TOKEN;

TOKEN analex();

extern double num;

