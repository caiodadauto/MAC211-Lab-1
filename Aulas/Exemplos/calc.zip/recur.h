#include "analex.h"
#define NVARS 100

extern double k[NVARS];
double expr();
double fator();
double term();
